<?php return array('version' => 'd80def381b2f3bb35576');
